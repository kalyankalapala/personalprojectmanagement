import React from "react";
import Map from "../containers/maps/Map";

const TaskPage = () => {
  return (
    <div>
      <Map />
    </div>
  );
};

export default TaskPage;
