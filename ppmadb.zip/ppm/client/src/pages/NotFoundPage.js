import React from "react";
import NotFound from "../containers/404/NotFound";

const NotFoundPage = () => {
  return (
    <div>
      <NotFound />
    </div>
  );
};

export default NotFoundPage;
