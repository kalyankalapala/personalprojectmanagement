import React from "react";
import SearchPage from "../containers/dashboard/SearchPage";

const SearchResults = () => {
  return (
    <div>
      <SearchPage />
    </div>
  );
};

export default SearchResults;
