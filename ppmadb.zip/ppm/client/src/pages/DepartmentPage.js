import React from 'react'
import DepartmentView from '../containers/departments/DepartmentView'

const DepartmentPage = () => {
  return (
    <div><DepartmentView/></div>
  )
}

export default DepartmentPage