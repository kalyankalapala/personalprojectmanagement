import React from "react";
import Register from "../containers/auth/Register";

const RegisterPage = () => {
  return (
    <div>
      <Register />
    </div>
  );
};

export default RegisterPage;
