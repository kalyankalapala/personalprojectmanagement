import React from 'react'
import EmployeeView from '../containers/employees/EmployeeView'

const EmployeeViewsPage = () => {
  return (
    <div><EmployeeView/></div>
  )
}

export default EmployeeViewsPage