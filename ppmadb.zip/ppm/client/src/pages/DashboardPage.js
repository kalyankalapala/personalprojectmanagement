import React from "react";
import Dashboard from "../containers/dashboard/Dashboard";

const DashboardPage = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default DashboardPage;
