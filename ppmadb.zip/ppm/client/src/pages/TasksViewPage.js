import React from 'react'
import TaskView from '../containers/tasks/TaskView'

const TasksViewPage = () => {
  return (
    <div><TaskView/></div>
  )
}

export default TasksViewPage