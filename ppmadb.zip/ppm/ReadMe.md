How to install the project
-----------------------------------------------
1. Extract the project.
2. Open the folder using visual studio code.
3. Open the terminal in visual studio code and type "cd server" to enter the server directory
4. Then type "npm i" and press enter to install modules that the project depend on
5. Then type "node index.js" or "nodemon index.js" and press enter to start the server
6. Open another terminal and type "cd client" to enter the frontend side
7. Type "npm i" to install the node modules
8. Type "npm start" to start the frontend development server

